package com.example.projectworkmap.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface AvatarDao {
    @Query("SELECT * FROM avatars WHERE id = :id")
    fun getAvatar(id: Int): Avatar?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAvatar(avatar: Avatar)
}
