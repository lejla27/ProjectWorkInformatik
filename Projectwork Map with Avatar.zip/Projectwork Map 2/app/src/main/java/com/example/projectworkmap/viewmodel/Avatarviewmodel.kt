package com.example.projectworkmap.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.liveData
import androidx.lifecycle.viewModelScope
import com.example.projectworkmap.data.Avatar
import com.example.projectworkmap.data.AppDatabase
import kotlinx.coroutines.launch

class AvatarViewModel(application: Application) : AndroidViewModel(application) {
    private val avatarDao = AppDatabase.getDatabase(application, viewModelScope).avatarDao()

    fun getAvatar(id: Int): LiveData<Avatar?> = liveData {
        emit(avatarDao.getAvatar(id))
    }

    fun insertAvatar(avatar: Avatar) = viewModelScope.launch {
        avatarDao.insertAvatar(avatar)
    }
}
