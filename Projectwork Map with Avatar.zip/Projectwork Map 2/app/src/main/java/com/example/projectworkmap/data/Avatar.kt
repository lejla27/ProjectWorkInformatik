package com.example.projectworkmap.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "avatars")
data class Avatar(
    @PrimaryKey val id: Int,
    val name: String,
    val imageResource: Int // This holds the resource ID for the avatar image
)
