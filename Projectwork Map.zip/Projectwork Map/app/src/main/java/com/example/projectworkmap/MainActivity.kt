package com.example.projectworkmap

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.navigation.compose.rememberNavController
import com.example.projectworkmap.ui.theme.Graph
import com.example.projectworkmap.ui.theme.RouteStorage
import com.example.projectworkmap.ui.theme.TextViewModel
import java.util.LinkedList


class MainActivity : ComponentActivity() {

    private lateinit var graph: Graph
    private lateinit var routeStorage: RouteStorage

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val textViewModel: TextViewModel by viewModels {
            TextViewModel.factory
        } // Pass the factory explicitly

        routeStorage = RouteStorage(this)

        initializeGraph()

        val cities = listOf("Munich", "Augsburg", "Ulm", "Stuttgart") // images are not adaptable to the cities in the list (yet)
        setContent {
            val navController = rememberNavController()
            NavGraph(navController = navController, textViewModel = textViewModel, cities = cities)
        }

        // Example of finding a route and saving it
        val shortestPathList = graph.findShortestPath("Ulm", "Salzburg")
        val shortestPath = LinkedList(shortestPathList)
        println("Shortest Path: $shortestPath")
        routeStorage.saveRouteToFile(shortestPath, "shortest_path.txt")
    }

    private fun initializeGraph() {
        graph = Graph()
        graph.addEdge(source = "Munich", destination = "Augsburg", weight = 1)
        graph.addEdge(source = "Augsburg", destination = "Munich", weight = 1)

        graph.addEdge(source = "Augsburg", destination = "Ulm", weight = 1)
        graph.addEdge(source = "Ulm", destination = "Augsburg", weight = 1)

        graph.addEdge(source = "Ulm", destination = "Stuttgart", weight = 1)
        graph.addEdge(source = "Stuttgart", destination = "Ulm", weight = 1)

        graph.addEdge(source = "Munich", destination = "Salzburg", weight = 1)
        graph.addEdge(source = "Salzburg", destination = "Munich", weight = 1)

        graph.addEdge(source = "Munich", destination = "Rosenheim", weight = 1)
        graph.addEdge(source = "Rosenheim", destination = "Munich", weight = 1)

        graph.addEdge(source = "Rosenheim", destination = "Salzburg", weight = 1)
        graph.addEdge(source = "Salzburg", destination = "Rosenheim", weight = 1)

        graph.addEdge(source = "Starnberg", destination = "Augsburg", weight = 1)
        graph.addEdge(source = "Augsburg", destination = "Starnberg", weight = 1)

        graph.addEdge(source = "Heilbronn", destination = "Stuttgart", weight = 1)
        graph.addEdge(source = "Stuttgart", destination = "Heilbronn", weight = 1)

        graph.addEdge(source = "Garching", destination = "Munich", weight = 1)
        graph.addEdge(source = "Munich", destination = "Garching", weight = 1)
    }

}


