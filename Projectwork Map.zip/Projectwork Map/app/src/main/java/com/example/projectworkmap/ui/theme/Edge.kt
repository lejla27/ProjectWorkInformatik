package com.example.projectworkmap.ui.theme

data class Edge(val destination: String, var weight: Int)
